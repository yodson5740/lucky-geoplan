package ci.luckytrans.geoplan;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Surface;
import android.view.WindowManager;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Boussole native : capteur « vecteur de rotation » d'Android (gyroscope + magnétomètre fusionnés).
 * Envoie le cap (0-360°, Nord magnétique) jusqu'à 60 fois par seconde, à plat comme téléphone debout.
 */
@CapacitorPlugin(name = "Compass")
public class CompassPlugin extends Plugin implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor rotationSensor;
    private boolean running = false;
    private long lastSent = 0;
    private int sensorAccuracy = 3;
    private final float[] rot = new float[9];

    @Override
    public void load() {
        sensorManager = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            if (rotationSensor == null) {
                rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR);
            }
        }
    }

    @PluginMethod
    public void start(PluginCall call) {
        JSObject ret = new JSObject();
        if (sensorManager == null || rotationSensor == null) {
            ret.put("available", false);
            call.resolve(ret);
            return;
        }
        running = true;
        sensorManager.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_GAME);
        ret.put("available", true);
        call.resolve(ret);
    }

    @PluginMethod
    public void stop(PluginCall call) {
        running = false;
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
        call.resolve();
    }

    @Override
    protected void handleOnPause() {
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
        super.handleOnPause();
    }

    @Override
    protected void handleOnResume() {
        super.handleOnResume();
        if (running && sensorManager != null && rotationSensor != null) {
            sensorManager.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_GAME);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        long now = System.currentTimeMillis();
        if (now - lastSent < 16) {
            return;
        }
        lastSent = now;
        SensorManager.getRotationMatrixFromVector(rot, event.values);
        // Axe « haut du téléphone » (colonne 1) ou « arrière du téléphone » (−colonne 2) dans le repère Est/Nord
        double yEast = rot[1];
        double yNorth = rot[4];
        double heading;
        if (Math.hypot(yEast, yNorth) >= 0.5) {
            heading = Math.toDegrees(Math.atan2(yEast, yNorth));
        } else {
            heading = Math.toDegrees(Math.atan2(-rot[2], -rot[5]));
        }
        heading += displayRotation();
        heading = ((heading % 360) + 360) % 360;
        JSObject data = new JSObject();
        data.put("heading", heading);
        data.put("accuracy", sensorAccuracy);
        notifyListeners("heading", data);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        sensorAccuracy = accuracy;
    }

    private int displayRotation() {
        try {
            WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
            int r = wm.getDefaultDisplay().getRotation();
            if (r == Surface.ROTATION_90) return 90;
            if (r == Surface.ROTATION_180) return 180;
            if (r == Surface.ROTATION_270) return 270;
        } catch (Exception ignored) {
        }
        return 0;
    }
}
