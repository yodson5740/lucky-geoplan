package ci.luckytrans.geoplan;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
