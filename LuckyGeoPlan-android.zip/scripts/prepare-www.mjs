// Prépare le dossier www/ de l'application Android à partir des fichiers web du dépôt.
// Les bibliothèques (Leaflet, jsPDF) sont intégrées localement : l'appli démarre même sans Internet.
import fs from 'node:fs'; import path from 'node:path';
const SRC = path.resolve(process.env.WEB_SRC || '..');   // dossier contenant index.html
const OUT = path.resolve('www');
const must = f => { if (!fs.existsSync(path.join(SRC, f))) { console.error(`❌ Fichier manquant : ${f} (cherché dans ${SRC})`); process.exit(1); } };
must('index.html');
fs.rmSync(OUT, { recursive: true, force: true }); fs.mkdirSync(path.join(OUT, 'lib/leaflet'), { recursive: true });
for (const f of fs.readdirSync(SRC)) {
  if (/\.(png|webmanifest|svg|ico|jpg|webp)$/i.test(f)) fs.copyFileSync(path.join(SRC, f), path.join(OUT, f));
}
if (fs.existsSync(path.join(SRC, 'icons'))) fs.cpSync(path.join(SRC, 'icons'), path.join(OUT, 'icons'), { recursive: true });
fs.cpSync('node_modules/leaflet/dist/images', path.join(OUT, 'lib/leaflet/images'), { recursive: true });
fs.copyFileSync('node_modules/leaflet/dist/leaflet.js', path.join(OUT, 'lib/leaflet/leaflet.js'));
fs.copyFileSync('node_modules/leaflet/dist/leaflet.css', path.join(OUT, 'lib/leaflet/leaflet.css'));
fs.copyFileSync('node_modules/jspdf/dist/jspdf.umd.min.js', path.join(OUT, 'lib/jspdf.umd.min.js'));
fs.mkdirSync(path.join(OUT, 'lib/firebase'), { recursive: true });
for (const n of ['app', 'auth', 'firestore']) fs.copyFileSync(`node_modules/firebase/firebase-${n}-compat.js`, path.join(OUT, `lib/firebase/firebase-${n}-compat.js`));
let html = fs.readFileSync(path.join(SRC, 'index.html'), 'utf8');
const rep = [
  [/https:\/\/cdn\.jsdelivr\.net\/npm\/leaflet@[\d.]+\/dist\/leaflet\.css/g, 'lib/leaflet/leaflet.css'],
  [/https:\/\/cdn\.jsdelivr\.net\/npm\/leaflet@[\d.]+\/dist\/leaflet\.js/g, 'lib/leaflet/leaflet.js'],
  [/https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/jspdf\/[\d.]+\/jspdf\.umd\.min\.js/g, 'lib/jspdf.umd.min.js'],
  [/https:\/\/cdn\.jsdelivr\.net\/npm\/firebase@[\d.]+\//g, 'lib/firebase/'],
];
for (const [re, to] of rep) { if (!re.test(html)) { console.error('❌ Lien introuvable dans index.html : ' + re); process.exit(1); } html = html.replace(re, to); }
fs.writeFileSync(path.join(OUT, 'index.html'), html);
console.log('✅ www/ prêt depuis ' + SRC + ' (' + fs.readdirSync(OUT).length + ' éléments)');
